﻿using System;

namespace HCNetSDK
{
    public class Class1
    {
    }
}
