Sergio Joel Ferreras Batista: 8:07PM EST-4:00 27/05/2019

To generate the nuget package from zero, first create the corresponding Binding for the Hikvision SDK.

Then go ahead with the Microsoft Documentation:

https://docs.microsoft.com/en-us/nuget/create-packages/creating-a-package

