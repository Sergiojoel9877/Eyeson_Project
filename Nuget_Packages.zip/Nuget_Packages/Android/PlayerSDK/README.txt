Sergio Joel Ferreras Batista: 8:05PM EST-4:00 27/05/2019

To generate the nuget package from zero, first create the corresponding Binding for the Player SDK.

Then go ahead with the Microsoft Documentation:

https://docs.microsoft.com/en-us/nuget/create-packages/creating-a-package

